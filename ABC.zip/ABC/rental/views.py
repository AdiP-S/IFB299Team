from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, 'rental/home.html')

def database(request):
    return render(request,'rental/database.html')

def about(request):
    return render(request,'rental/about.html')

def viewVehicle(request):
    return render(request,'rental/viewVehicle.html')

def Checkout(request):
    return render(request,'rental/Checkout.html')

def CheckoutResult(request):
    return render(request,'rental/CheckoutResult.html')