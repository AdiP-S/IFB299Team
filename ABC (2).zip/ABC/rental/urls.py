from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name ='rental-home'),
    path('database/', views.database, name='rental-database'),
    path('viewVehicle/', views.viewVehicle, name='rental-viewVehicle'),
    path('about/', views.about, name='rental-about'),
    path('Checkout/', views.Checkout, name='rental-Checkout'),
    path('CheckoutResult/', views.CheckoutResult, name='rental-CheckoutResult'),
    
]
