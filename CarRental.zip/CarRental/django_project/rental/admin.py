from django.contrib import admin
from .models import Customers_Rental
# Register your models here.
admin.site.register(Customers_Rental)
