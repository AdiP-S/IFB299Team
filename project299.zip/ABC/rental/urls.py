from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name ='rental-home'),
    path('searchPage/', views.searchPage, name='rental-searchPage'),
    path('viewVehicle/', views.viewVehicle, name='rental-viewVehicle'),
    path('about/', views.about, name='rental-about'),
    
]
