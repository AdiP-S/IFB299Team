from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, 'rental/home.html')

def searchPage(request):
    return render(request,'rental/searchPage.html')

def about(request):
    return render(request,'rental/about.html')

def viewVehicle(request):
    return render(request,'rental/viewVehicle.html')